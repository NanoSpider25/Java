import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;

public class frmZPG{
    public frmZPG(JFrame f){
        initComponents(f);
        this.f = f;
    }
    public static void main(String[] Z){
        JFrame f = new JFrame();
        frmZPG frmzpg = new frmZPG(f);
    }
    public void initComponents(JFrame f){
        f.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        f.setSize(500,500);
        /*
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(f.getContentPane());
        f.getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 705, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 394, Short.MAX_VALUE)
        );

        f.pack();*/
        createArrays(100,100,f);
        f.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {

            }

            @Override
            public void keyPressed(KeyEvent e) {
                char key = e.getKeyChar();
                if (key == 'e' || key == 'E'){
                    for (int i = 1; i < grid.length-1; i++) {
                        for (int j = 1; j < grid[i].length-1; j++) {
                            grid[i][j] = 0;
                        }
                    }
                }


                if (key == 'r' || key == 'R'){
                    Randomize();
                }

                if (key == 'c' || key == 'C'){
                    Change();
                }

                display();

            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });
        f.setVisible(true);
        gameloop(100000000,100);
    }


    private int[][] grid;
    private JPanel[][] pnlArr;
    private boolean pause = false;

    public void gameloop(int sec, int milli){
        int count = -1;
    while (count < sec) {
        if (!pause){
        display();
        count++;
        int[][] gridT = new int[pnlArr.length][pnlArr[0].length];
        for (int i = 1; i < pnlArr.length - 1; i++) {
            for (int j = 1; j < pnlArr[i].length - 1; j++) {

                int state = grid[i][j];
                int live = 0;
                for (int k = i - 1; k <= i + 1; k++) {
                    for (int l = j - 1; l <= j + 1; l++) {
                        if ((k != i || l != j) && (grid[k][l] == 1)) {
                            live++;
                        }
                    }
                }
                if (state == 1) {
                    if (live < 2) {
                        state = 0;
                    }
                    if (live > 3) {
                        state = 0;
                    }
                } else {
                    if (live == 3) {
                        state = 1;
                    }
                }
                gridT[i][j] = state;

            }
        }
        for (int i = 0; i < gridT.length; i++) {
            for (int j = 0; j < gridT[i].length; j++) {
                grid[i][j] = gridT[i][j];
            }
        }
        display();
        try {
            Thread.sleep(milli);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    }/*
        System.out.println("Finito");
    double avg = 0;
        for (int i = 1; i < r-1; i++) {
            for (int j = 1; j < c-1; j++) {
                avg += grid[i][j];
            }
        }
        avg = avg/((r-2)*(c-2));
        System.out.println(avg*100);*/
    }

    private int r,c;
    private JFrame f;

    public void Change(){
        while (true){
            try{
                r = Integer.parseInt(JOptionPane.showInputDialog("Rows?","10"));
                c = Integer.parseInt(JOptionPane.showInputDialog("Columns?","10"));
                break;
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        for (int i = 1; i < grid.length-1; i++) {
            for (int j = 1; j < grid[i].length-1; j++) {
                grid[i][j] = 0;
            }
        }
        display();
        createArrays(r,c,f);
    }


    public void Randomize(){

        Random random = new Random();
        for (int i = 0; i < c; i++) {
            grid[0][i] = 0;
            grid[r-1][i] = 0;
        }
        for (int i = 0; i < r; i++) {
            grid[i][0] = 0;
            grid[i][c-1] = 0;
        }

        for (int i = 1; i < r-1; i++) {
            for (int j = 1; j < c-1; j++) {
                grid[i][j] = random.nextInt(2);
            }
        }
    }

    public void createArrays(int r, int c, JFrame frame) {
        grid = new int[r][c];
        pnlArr = new JPanel[r][c];
        this.r = r;
        this.c = c;
        // Use a GridLayout to organize the panels in a grid
        //frame.setLayout(new GridLayout(r, c));
        Randomize();

        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {
                pnlArr[i][j] = new JPanel();
                pnlArr[i][j].setSize(10, 10);
                pnlArr[i][j].setLocation(j*10,i*10);
                pnlArr[i][j].setVisible(true);
                if (grid[i][j] == 0) {
                    pnlArr[i][j].setBackground(Color.black);
                } else {
                    pnlArr[i][j].setBackground(Color.white);
                }
                pnlArr[i][j].addMouseListener(new pnlMouseListener(pnlArr[i][j]));
                frame.add(pnlArr[i][j]);
            }
        }

    }
    public void display(){
        for (int i = 0; i < grid.length; i++){
            for(int j = 0; j < grid[i].length; j++){
                if(grid[i][j] == 0){
                    pnlArr[i][j].setBackground(Color.black);
                }else{
                    pnlArr[i][j].setBackground(Color.white);
                }
            }
        }
    }



    private class pnlMouseListener extends MouseAdapter{
        private JPanel pnl;
        public pnlMouseListener(JPanel pnl){
            this.pnl = pnl;
        }
        @Override
        public void mousePressed(MouseEvent e){
            Point p = pnl.getLocation();
            try {
                if (grid[p.y / 10][p.x / 10] == 0) {
                    grid[p.y / 10][p.x / 10] = 1;
                } else {
                    grid[p.y / 10][p.x / 10] = 0;
                }
            }catch(Exception ex){

            }
            display();
        }
    }
}
