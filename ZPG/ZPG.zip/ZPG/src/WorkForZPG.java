/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.awt.Color;
import java.util.Random;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author Student
 */
public class WorkForZPG {

    private int[][] grid;
    private JPanel[][] pnlArr;

    public void createArrays(int r, int c, JFrame frame){
        grid = new int[r][c];
        pnlArr = new JPanel[r][c];
        Random random = new Random();
        for (int i = 0; i < r; i++){
            for (int j = 0; j < c; j++){
                grid[i][j] = random.nextInt(2);
                pnlArr[i][j] = new JPanel();
                pnlArr[i][j].setSize(10,10);
                pnlArr[i][j].setVisible(true);
                frame.add(pnlArr[i][j]);
                System.out.println(i);
            }
        }
        display();
    }

    public void display(){
        for (int i = 0; i < grid.length; i++){
            for(int j = 0; j < grid[i].length; j++){
                if(grid[i][j] == 0){
                    pnlArr[i][j].setBackground(Color.black);
                }else{
                    pnlArr[i][j].setBackground(Color.white);
                }
            }
        }
    }

}
